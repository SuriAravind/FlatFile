CREATE DATABASE  IF NOT EXISTS `claims_sys` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `claims_sys`;
-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: claims_sys
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `provider`
--

DROP TABLE IF EXISTS `provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider` (
  `PROV_ID` int NOT NULL,
  `PROV_NAME` varchar(255) NOT NULL,
  `IS_PHYSICIAN` bit(1) NOT NULL DEFAULT b'0',
  `IS_FACILITY` bit(1) NOT NULL DEFAULT b'1',
  `TIN_SSN` int NOT NULL,
  `ADDR_ID` int NOT NULL,
  `PRIMARY_ADDR_TYPE` char(1) NOT NULL,
  `SECONDARY_ADDR_TYPE` char(1) NOT NULL,
  PRIMARY KEY (`PROV_ID`,`ADDR_ID`),
  KEY `i1` (`ADDR_ID`,`PRIMARY_ADDR_TYPE`),
  KEY `i2` (`ADDR_ID`,`SECONDARY_ADDR_TYPE`),
  CONSTRAINT `ADDR_3` FOREIGN KEY (`ADDR_ID`, `PRIMARY_ADDR_TYPE`) REFERENCES `address` (`ADDR_ID`, `ADDR_TYPE`),
  CONSTRAINT `ADDR_4` FOREIGN KEY (`ADDR_ID`, `SECONDARY_ADDR_TYPE`) REFERENCES `address` (`ADDR_ID`, `ADDR_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider`
--

LOCK TABLES `provider` WRITE;
/*!40000 ALTER TABLE `provider` DISABLE KEYS */;
INSERT INTO `provider` VALUES (90001,'Wikizz',_binary '\0',_binary '',739380409,90001,'F','O'),(90002,'Wordpedia',_binary '\0',_binary '',300954734,90002,'F','O'),(90003,'Oyondu',_binary '\0',_binary '',677526648,90003,'F','O'),(90004,'Edgewire',_binary '\0',_binary '',571433429,90004,'F','O'),(90005,'Linkbuzz',_binary '\0',_binary '',650180889,90005,'F','O'),(90006,'Oyope',_binary '\0',_binary '',382598453,90006,'F','O'),(90007,'Shufflebeat',_binary '\0',_binary '',257583788,90007,'F','O'),(90008,'Thoughtworks',_binary '\0',_binary '',449105240,90008,'F','O'),(90009,'Dr. Carl Ruiz',_binary '',_binary '\0',155710318,90009,'H','F'),(90010,'Dr. Pamela Little',_binary '',_binary '\0',859152344,90010,'H','F'),(90011,'Dr. Julia Graham',_binary '',_binary '\0',120750949,90011,'H','F'),(90012,'Dr. Diana Morris',_binary '',_binary '\0',866696761,90012,'H','F'),(90013,'Dr. Barbara Frazier',_binary '',_binary '\0',152634612,90013,'H','F'),(90014,'Dr. Chris Morales',_binary '',_binary '\0',863137859,90014,'H','F'),(90015,'Dr. Anne Vasquez',_binary '',_binary '\0',709247683,90015,'H','F');
/*!40000 ALTER TABLE `provider` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-07 18:39:25
