CREATE DATABASE  IF NOT EXISTS `claims_sys` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `claims_sys`;
-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: claims_sys
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dx_code`
--

DROP TABLE IF EXISTS `dx_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dx_code` (
  `DX_CODE` int NOT NULL,
  `DX_DESC` varchar(1000) NOT NULL,
  PRIMARY KEY (`DX_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dx_code`
--

LOCK TABLES `dx_code` WRITE;
/*!40000 ALTER TABLE `dx_code` DISABLE KEYS */;
INSERT INTO `dx_code` VALUES (101,'Fitting and adjustment of other gastrointestinal appliance and device'),(102,'Other specified delays in development'),(103,'Attention to artificial vagina'),(104,'Endocrine disorder arising from mental factors'),(105,'Closed fracture of shaft of tibia alone'),(106,'Traumatic amputation of leg(s) (complete) (partial), unilateral, below knee, without mention of complication'),(107,'Nonspecific mesenteric lymphadenitis'),(108,'Poisoning by parasympathomimetics (cholinergics)'),(109,'Femoral hernia with obstruction, unilateral or unspecified (not specified as recurrent)'),(110,'Polyostotic fibrous dysplasia of bone'),(111,'Tuberculosis of mastoid, tubercle bacilli not found (in sputum) by microscopy, but found by bacterial culture'),(112,'Malignant neoplasm of other specified sites of nervous system'),(113,'Deep necrosis of underlying tissues [deep third degree] with loss of a body part, of multiple sites of upper limb, except wrist and hand'),(114,'Other and unspecified fall in water transport injuring occupant of small boat, powered'),(115,'Infection with microorganisms resistant to aminoglycosides'),(116,'Bipolar I disorder, single manic episode, moderate'),(117,'Frostbite of other and unspecified sites'),(118,'Loose body in joint, hand'),(119,'Tuberculous abscess of spinal cord, bacteriological or histological examination not done'),(120,'Sprain of sternum, unspecified site'),(121,'Other specified paranoid states'),(122,'Open wound of ear, part unspecified, without mention of complication'),(123,'Adjustment reaction with physical symptoms'),(124,'Cerebellar or brain stem contusion without mention of open intracranial wound, with moderate [1-24 hours] loss of consciousness'),(125,'Motor vehicle traffic accident involving collision with pedestrian injuring motorcyclist'),(126,'Dacryocystitis, unspecified'),(127,'Other malignant secondary hypertension'),(128,'Lipoma of other specified sites'),(129,'Other specified pulmonary tuberculosis, tubercle bacilli found (in sputum) by microscopy'),(130,'Gonococcal infection of anus and rectum'),(131,'Other forms of placental separation and hemorrhage affecting fetus or newborn'),(132,'Obscure cardiomyopathy of Africa'),(133,'Fall in, on, or from aircraft injuring occupant of unpowered aircraft, except parachutist'),(134,'T1-T6 level with other specified spinal cord injury'),(135,'Injury to descending [left] colon, without mention of open wound into cavity'),(136,'Sezary\'s disease, intra-abdominal lymph nodes'),(137,'Acute suppurative otitis media in diseases classified elsewhere'),(138,'Old disruption of anterior cruciate ligament'),(139,'Open wound of hip and thigh, without mention of complication'),(140,'Injury to median nerve'),(141,'Foreign body, magnetic, in lens'),(142,'Polyneuropathy in diabetes'),(143,'Open wound of scrotum and testes, complicated'),(144,'Motor vehicle traffic accident involving re-entrant collision with another motor vehicle injuring other specified person'),(145,'Mechanical complication due to breast prosthesis'),(146,'Benign hypertensive heart disease without heart failure'),(147,'Other and unspecified malignant neoplasms of lymphoid and histiocytic tissue, lymph nodes of multiple sites'),(148,'Alkalizing agents causing adverse effects in therapeutic use'),(149,'Benign hypertensive heart disease with heart failure'),(150,'Arthropathy associated with mycoses, ankle and foot'),(151,'Other acquired deformities of forearm, excluding fingers'),(152,'Acute tracheitis with obstruction'),(153,'Twin birth, mate liveborn, born before admission to hospital'),(154,'Disfigurements of limbs'),(155,'Combinations of opioid type drug with any other drug dependence, unspecified'),(156,'Air embolism as a complication of medical care, not elsewhere classified'),(157,'Maternal hypotension syndrome, postpartum condition or complication'),(158,'Closed fracture of sacrum and coccyx with other spinal cord injury'),(159,'Hemolytic disease of fetus or newborn due to ABO isoimmunization'),(160,'Urinary tract infection of newborn'),(161,'Kidney dialysis as the cause of abnormal reaction of patient, or of later complication, without mention of misadventure at time of procedure'),(162,'Falling from unspecified site, undetermined whether accidentally or purposely inflicted'),(163,'Mechanical failure of instrument or apparatus during heart catheterization'),(164,'Hodgkin\'s granuloma, spleen'),(165,'Disorders of visual cortex associated with inflammatory disorders'),(166,'Unequal leg length (acquired)'),(167,'Other joint derangement, not elsewhere classified, forearm'),(168,'Flaccid hemiplegia and hemiparesis affecting nondominant side'),(169,'Swan-neck deformity'),(170,'Abrasion or friction burn of foot and toe(s), infected'),(171,'Loose body in joint, ankle and foot'),(172,'Other hemorrhagic disorder due to intrinsic circulating anticoagulants, antibodies, or inhibitors'),(173,'Toxic effect of organophosphate and carbamate'),(174,'Brill\'s disease'),(175,'Aneurysm of other visceral artery'),(176,'Unsatisfactory vaginal cytology smear'),(177,'Catatonic type schizophrenia, in remission'),(178,'Septicemic plague'),(179,'Bone marrow donors'),(180,'Dissection of coronary artery'),(181,'Gastrostomy status'),(182,'Abnormality of secretion of glucagon'),(183,'Open fracture of rib(s), unspecified'),(184,'Fetal growth retardation, unspecified, 2,000-2,499 grams'),(185,'Explosive personality disorder'),(186,'Tuberculoid leprosy [type T]'),(187,'Unspecified disorder of parathyroid gland'),(188,'Hodgkin\'s disease, nodular sclerosis, unspecified site, extranodal and solid organ sites'),(189,'Primary tuberculous infection, unspecified, tubercle bacilli not found (in sputum) by microscopy, but found by bacterial culture'),(190,'Cortex (cerebral) contusion with open intracranial wound, with concussion, unspecified'),(191,'Tuberculosis of eye, tubercle bacilli not found by bacteriological or histological examination, but tuberculosis confirmed by other methods [inoculation of animals]'),(192,'Tuberculosis of limb bones, tubercle bacilli not found by bacteriological examination, but tuberculosis confirmed histologically'),(193,'Infantile spasms, with intractable epilepsy'),(194,'Acute miliary tuberculosis, tubercle bacilli found (in sputum) by microscopy'),(195,'Trans-sexualism with heterosexual history'),(196,'Arthropathy associated with hypersensitivity reaction'),(197,'Medullary sponge kidney'),(198,'Postpartum care and examination immediately after delivery'),(199,'Abdominal pain, unspecified site'),(200,'Attention to other specified artificial opening');
/*!40000 ALTER TABLE `dx_code` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-07 18:39:25
