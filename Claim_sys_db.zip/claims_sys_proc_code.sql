CREATE DATABASE  IF NOT EXISTS `claims_sys` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `claims_sys`;
-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: claims_sys
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `proc_code`
--

DROP TABLE IF EXISTS `proc_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proc_code` (
  `PROC_CODE` int NOT NULL,
  `PROC_DESC` varchar(1000) NOT NULL,
  PRIMARY KEY (`PROC_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proc_code`
--

LOCK TABLES `proc_code` WRITE;
/*!40000 ALTER TABLE `proc_code` DISABLE KEYS */;
INSERT INTO `proc_code` VALUES (31,'Excision of tonsil tag'),(51,'Open total intra-abdominal colectomy'),(74,'Substernal thyroidectomy, not otherwise specified'),(222,'Partial excision of pituitary gland, transfrontal approach'),(650,'Other partial excision of thymus'),(729,'Other repair of anal sphincter'),(762,'Canthotomy'),(795,'Microscopic examination of specimen from trachea, bronchus, pleura, lung, and other thoracic specimen, and of sputum, culture and sensitivity'),(842,'Packing of external auditory canal'),(1122,'Removal of catheter(s) from cranial cavity or tissue'),(1191,'Other excision of vessels, aorta, abdominal'),(1292,'Other excision of joint, hip'),(1311,'Other incision of thyroid field'),(1365,'Arthroscopy, foot and toe'),(1732,'Other excision of vessels, lower limb veins'),(1741,'Removal of implanted devices from bone, other bones'),(1744,'Other excision of joint, elbow'),(2032,'Open reduction of fracture without internal fixation, radius and ulna'),(2041,'Prescription, fitting, and dispensing of contact lens'),(2095,'Delayed opening of other enterostomy'),(2641,'Extended ophthalmologic work-up'),(2649,'Biopsy of perianal tissue'),(2752,'Excision of secondary membrane [after cataract]'),(2912,'Excision of other lesion of soft tissue of hand'),(3029,'Microscopic examination of specimen from skin and other integument, toxicology'),(3161,'Other incision of soft tissue of hand'),(3392,'Local excision or destruction of lesion of facial bone'),(3423,'Lengthening procedure on one extraocular muscle'),(3425,'Contrast radiogram of orbit'),(3501,'Microscopic examination of specimen from upper gastrointestinal tract and of vomitus, culture and sensitivity'),(3521,'Removal of carotid sinus stimulation lead(s) only'),(3561,'Injection or infusion of biological response modifier [BRM] as an antineoplastic agent'),(3770,'Osteoclasis, tarsals and metatarsals'),(3792,'Implantation of cardiac resynchronization pacemaker without mention of defibrillation, total system [CRT-P]'),(3798,'Arteriovenostomy for renal dialysis'),(3851,'Open biopsy of larynx or trachea'),(3869,'Other repair or plastic operations on bone, femur'),(3887,'Other arthrotomy, hand and finger'),(3991,'Local excision of lesion or tissue of bone, tarsals and metatarsals'),(4143,'Closed [percutaneous] [needle] biopsy of intra-abdominal mass'),(4225,'Fixation of intestine, not otherwise specified'),(4289,'Manual exploration of uterine cavity, postpartum'),(4501,'Microscopic examination of specimen from nervous system and of spinal fluid, toxicology'),(4513,'Prophylactic vaccination against influenza'),(4542,'Other cervical fusion of the posterior column, posterior technique'),(4575,'Other excision of joint, hand and finger'),(4639,'Advancement of one extraocular muscle'),(4701,'Refusion of lumbar and lumbosacral spine, anterior column, posterior technique'),(4892,'Microscopic examination of specimen from eye, cell block and Papanicolaou smear'),(5110,'Contrast dacryocystogram'),(5133,'Rhinoscopy'),(5293,'Application of pressure dressing'),(5314,'Microscopic examination of specimen from kidney, ureter, perirenal and periureteral tissue, culture and sensitivity'),(5496,'Correction of lid retraction'),(5584,';INSERTion of bone growth stimulator, patella'),(5751,'Biopsy of bone, humerus'),(5794,'Percutaneous pyelogram'),(6013,'Other mechanical vitrectomy'),(6071,'Open biopsy of kidney'),(6539,'Therapeutic ultrasound of vessels of head and neck'),(6629,'Other diagnostic procedures on orbit and eyeball'),(6816,'Other diagnostic procedures on small intestine'),(6929,'Other orbitotomy'),(7535,'Revision of tympanoplasty'),(7669,'Biopsy of perirenal or perivesical tissue'),(7718,'Repair of entropion or ectropion by suture technique'),(7762,'Turbinectomy by diathermy or cryosurgery'),(7789,'Restoration of tooth by filling'),(7849,'Muscle transfer or transplantation'),(7937,'Laparoscopic incisional hernia repair with graft or prosthesis'),(7967,'Triple arthrodesis'),(8001,'Biopsy of pituitary gland, unspecified approach'),(8034,'Osteoclasis, radius and ulna'),(8088,'Laparoscopic cholecystectomy'),(8091,'Myotomy'),(8098,'Amnioinfusion'),(8164,'Laparoscopic ablation of liver lesion or tissue'),(8246,'Diagnostic procedures on bone, not elsewhere classified, patella'),(8284,'Other operations on ciliary body'),(8309,'Thyroid tissue reimplantation'),(8343,'Closure of other fistula of pharynx'),(8542,'Angiocardiography of left heart structures'),(8734,'Percutaneous angioplasty of extracranial vessel(s)'),(8801,'Other vaginotomy'),(8815,'Dilation of esophagus'),(8827,'Other repair of kidney'),(8843,'Dark adaptation study'),(8903,'Resection of vessel with anastomosis, intracranial vessels'),(8962,'Total body scan'),(9013,'Arthrotomy for removal of prosthesis without replacement, elbow'),(9104,'Correction of syndactyly'),(9181,'Open reduction of fracture without internal fixation, radius and ulna'),(9196,'Other tenonectomy of hand'),(9203,'Limb shortening procedures, radius and ulna'),(9227,'Other parathyroidectomy'),(9355,'Other and open bilateral repair of indirect inguinal hernia'),(9446,'Allogeneic bone marrow transplant with purging'),(9449,'Total excision of pituitary gland, unspecified approach'),(9502,'Contrast vasogram'),(9734,'Cricopharyngeal myotomy');
/*!40000 ALTER TABLE `proc_code` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-07 18:39:25
