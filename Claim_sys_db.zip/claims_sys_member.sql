CREATE DATABASE  IF NOT EXISTS `claims_sys` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `claims_sys`;
-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: claims_sys
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `MEM_ID` int NOT NULL,
  `SUB_ID` int NOT NULL,
  `MEM_FIRST_NAME` varchar(255) NOT NULL,
  `MEM_LAST_NAME` varchar(255) NOT NULL,
  `MEM_REL` char(1) NOT NULL,
  `MEM_SEX` char(1) NOT NULL,
  `MEM_DOB` datetime NOT NULL,
  `FAMILY_LINK_ID` int NOT NULL,
  `ADDR_ID` int NOT NULL,
  `IS_SUB` bit(1) DEFAULT b'0',
  `PRIMARY_ADDR_TYPE` char(1) DEFAULT 'H',
  `SECONDARY_ADDR_TYPE` char(1) DEFAULT 'H',
  PRIMARY KEY (`MEM_ID`),
  KEY `SUB_ID` (`SUB_ID`),
  KEY `i1` (`ADDR_ID`,`PRIMARY_ADDR_TYPE`),
  KEY `i2` (`ADDR_ID`,`SECONDARY_ADDR_TYPE`),
  CONSTRAINT `ADDR_1` FOREIGN KEY (`ADDR_ID`, `PRIMARY_ADDR_TYPE`) REFERENCES `address` (`ADDR_ID`, `ADDR_TYPE`),
  CONSTRAINT `ADDRE_2` FOREIGN KEY (`ADDR_ID`, `SECONDARY_ADDR_TYPE`) REFERENCES `address` (`ADDR_ID`, `ADDR_TYPE`),
  CONSTRAINT `member_ibfk_1` FOREIGN KEY (`SUB_ID`) REFERENCES `subscriber` (`SUB_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (10000100,100001,'Jerry','Phillips','Z','M','1986-02-17 16:40:29',100001,100001,_binary '','H','O'),(10000101,100001,'Randy','Phillips','S','M','2003-07-03 22:43:24',100001,100001,_binary '\0','H','O'),(10000200,100002,'Ruth','Cook','Z','M','1990-05-30 19:12:12',100002,100002,_binary '','H','O'),(10000201,100002,'Craig','Cook','S','M','2013-09-22 23:27:09',100002,100002,_binary '\0','H','O'),(10000202,100002,'Patrick','Cook','S','M','2012-09-22 23:28:24',100002,100002,_binary '\0','H','O'),(10000300,100003,'Gerald','Campbell','Z','M','1984-04-30 04:06:23',100003,100003,_binary '','H','O'),(10000400,100004,'Christine','Snyder','Z','F','1984-11-04 10:34:40',100004,100004,_binary '','H','O'),(10000401,100004,'Anna','Snyder','W','F','1980-11-18 22:53:17',100004,100004,_binary '\0','H','O'),(10000402,100004,'Dennis','Murray','S','M','2005-01-11 16:03:21',100004,100004,_binary '\0','H','O'),(10000403,100004,'Russell','Murray','S','M','2002-01-17 14:46:28',100004,100004,_binary '\0','H','O'),(10000500,100005,'Larry','Montgomery','Z','M','1982-03-28 02:32:20',100005,100005,_binary '','H','O'),(10000501,100005,'Anthony','Montgomery','F','M','1984-04-11 16:34:30',100005,100005,_binary '\0','H','O'),(10000600,100006,'Bonnie','Wagner','Z','M','1981-07-02 10:08:06',100006,100006,_binary '','H','O'),(10000601,100006,'Roger','Wagner','F','M','1960-10-31 05:42:41',100006,100006,_binary '\0','H','O'),(10000700,100007,'Diane','Moore','Z','M','1986-03-01 04:20:37',100007,100007,_binary '','H','O'),(10000701,100007,'Catherine','Moore','W','F','1986-09-08 07:10:49',100007,100007,_binary '\0','H','O'),(10000702,100007,'Lori','Robertson','S','M','2003-05-31 16:16:27',100007,100007,_binary '\0','H','O'),(10000800,100008,'Judy','Franklin','Z','F','1987-10-02 06:41:37',100008,100008,_binary '','H','O'),(10000801,100008,'Willie','Franklin','H','M','1985-02-18 04:37:16',100008,100008,_binary '\0','H','O'),(10000900,100009,'Barbara','Fox','Z','F','1986-03-29 01:27:04',100009,100009,_binary '','H','O'),(10000901,100009,'Stephanie','Fox','D','F','2009-06-30 05:15:27',100009,100009,_binary '\0','H','O'),(10000902,100009,'Jack','Fox','H','M','1984-02-08 06:13:32',100009,100009,_binary '\0','H','O'),(10000903,100009,'Dorothy','Bailey','D','F','2012-10-21 21:25:36',100009,100009,_binary '\0','H','O'),(10001000,100010,'Arthur','Kelly','Z','M','1985-09-16 08:10:08',100010,100010,_binary '','H','O'),(10001001,100010,'Julia','Kelly','W','F','1986-01-29 03:46:58',100010,100010,_binary '\0','H','O'),(10001100,100011,'Jerry','Carroll','Z','M','1983-10-21 19:27:40',100011,100011,_binary '','H','O'),(10001101,100011,'Joan','Carroll','S','M','2003-04-12 04:08:55',100011,100011,_binary '\0','H','O'),(10001102,100011,'Donna','Carroll','W','F','1984-03-04 19:02:39',100011,100011,_binary '\0','H','O'),(10001200,100012,'Dorothy','Bell','Z','F','1981-10-02 14:22:04',100012,100012,_binary '','H','O'),(10001201,100012,'Elizabeth','Bell','D','F','2006-06-14 07:48:03',100012,100012,_binary '\0','H','O'),(10001300,100013,'Chris','Garcia','Z','M','1986-12-23 14:48:29',100013,100013,_binary '','H','O'),(10001301,100013,'Carolyn','Garcia','S','M','2008-09-03 17:22:08',100013,100013,_binary '\0','H','O'),(10001400,100014,'Dennis','Coleman','Z','M','1982-11-26 16:10:42',100014,100014,_binary '','H','O'),(10001401,100014,'Thomas','Coleman','F','M','1960-07-10 00:27:50',100014,100014,_binary '\0','H','O'),(10001402,100014,'Albert','Coleman','S','M','2005-01-22 08:09:11',100014,100014,_binary '\0','H','O'),(10001500,100015,'Victor','Howell','Z','M','1981-02-12 15:33:42',100015,100015,_binary '','H','O'),(10001501,100015,'Louis','Howell','S','M','2005-10-06 05:46:39',100015,100015,_binary '\0','H','O'),(10001600,100016,'Gloria','Miller','Z','F','1986-06-24 10:13:56',100016,100016,_binary '','H','O'),(10001700,100017,'Marilyn','Gonzalez','Z','F','1987-07-12 00:22:53',100017,100017,_binary '','H','O'),(10001701,100017,'Bobby','Gonzalez','H','M','1987-02-04 16:33:05',100017,100017,_binary '\0','H','O'),(10001702,100017,'Carlos','Gonzalez','S','M','2008-05-24 07:08:43',100017,100017,_binary '\0','H','O'),(10001800,100018,'Julie','Reyes','Z','F','1989-07-28 00:02:49',100018,100018,_binary '','H','O'),(10001801,100018,'Brenda','Reyes','D','F','2012-10-13 04:46:08',100018,100018,_binary '\0','H','O'),(10001900,100019,'Brian','Butler','Z','M','1984-01-24 18:07:37',100019,100019,_binary '','H','O'),(10001901,100019,'Debra','Butler','W','F','1984-10-15 04:47:38',100019,100019,_binary '\0','H','O'),(10002000,100020,'Martin','Johnston','Z','M','1982-06-28 07:22:23',100020,100020,_binary '','H','O'),(10002001,100020,'Antonio','Johnston','S','M','2008-03-10 11:30:34',100020,100020,_binary '\0','H','O'),(10002100,100021,'Angela','Burns','Z','F','1988-06-26 11:43:48',100021,100021,_binary '','H','O'),(10002101,100021,'Judy','Burns','D','F','2008-05-26 14:34:16',100021,100021,_binary '\0','H','O'),(10002102,100021,'Douglas','Burns','H','M','1986-10-13 22:05:53',100021,100021,_binary '\0','H','O'),(10002200,100022,'George','Morris','Z','M','1983-04-11 07:03:25',100022,100022,_binary '','H','O'),(10002201,100022,'Paula','Morris','W','F','1984-01-11 09:51:33',100022,100022,_binary '\0','H','O'),(10002202,100022,'Carlos','Morris','S','M','2009-02-27 08:12:40',100022,100022,_binary '\0','H','O'),(10002300,100023,'Susan','Coleman','Z','F','1988-07-31 21:32:11',100023,100023,_binary '','H','O'),(10002301,100023,'Marilyn','Coleman','H','M','1986-01-19 15:24:15',100023,100023,_binary '\0','H','O'),(10002400,100024,'Emily','Howard','Z','F','1980-08-11 02:26:42',100024,100024,_binary '','H','O');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-07 18:39:25
